import unittest
from datetime import datetime
from habit import Habit
from db import Database
import json
import os

class TestHabit(unittest.TestCase):
    """
    Unit tests for the Habit class.
    """

    def setUp(self):
        """
        Sets up test data for the Habit class.
        """
        self.habit_daily = Habit(name="Daily Test", start_date=datetime(2024, 1, 1).date(), log=[
                                 datetime(2024, 6, 10).date(), datetime(2024, 6, 11).date()], periodicity="daily")
        self.habit_weekly = Habit(name="Weekly Test", start_date=datetime(2024, 1, 1).date(), log=[
                                  datetime(2024, 6, 9).date(), datetime(2024, 6, 16).date()], periodicity="weekly")

    def test_calculate_streak_daily(self):
        """
        Tests the calculate_streak method for a daily habit.
        """
        self.assertEqual(self.habit_daily.calculate_streak(), 2)

    def test_calculate_streak_weekly(self):
        """
        Tests the calculate_streak method for a weekly habit.
        """
        self.assertEqual(self.habit_weekly.calculate_streak(), 2)


class TestDatabase(unittest.TestCase):
    """
    Unit tests for the Database class.
    """

    def setUp(self):
        """
        Sets up test data for the Database class and creates a test database file.
        """
        self.db_file = "test_db.json"
        data = [
            {
                'name': 'Test Habit',
                'start_date': '2024-01-01',
                'log': ['2024-06-10', '2024-06-11'],
                'periodicity': 'daily'
            }
        ]
        with open(self.db_file, 'w') as file:
            json.dump(data, file)
        self.db = Database(db_file=self.db_file)

    def tearDown(self):
        """
        Cleans up by removing the test database file.
        """
        os.remove(self.db_file)

    def test_load_db(self):
        """
        Tests the load_db method to ensure habits are loaded correctly from the JSON file.
        """
        self.assertEqual(len(self.db.habits), 1)
        self.assertEqual(self.db.habits[0].name, "Test Habit")

    def test_save_db(self):
        """
        Tests the save_db method to ensure new habits are saved correctly to the JSON file.
        """
        new_habit = Habit(name="New Habit", start_date=datetime(2024, 6, 15).date(), log=[], periodicity="daily")
        self.db.habits.append(new_habit)
        self.db.save_db()

        with open(self.db_file, 'r') as file:
            data = json.load(file)
            self.assertEqual(len(data), 2)
            self.assertEqual(data[1]['name'], "New Habit")


if __name__ == '__main__':
    unittest.main()
