"""
This module provides the Database class for managing habits stored in a JSON file.
"""

import json
from habit import Habit
from datetime import datetime

class Database:
    """
    A class to represent the database of habits.
    """

    def __init__(self, db_file="db.json"):
        """
        Initializes the Database with a specified file.

        Args:
            db_file (str): The path to the JSON file storing the habits.
        """
        self.db_file = db_file
        self.habits = self.load_db()

    def load_db(self):
        """
        Loads the habits from the JSON file.

        Returns:
            list: A list of Habit objects.
        """
        try:
            with open(self.db_file, "r") as file:
                data = json.load(file)
                habits = []
                for item in data:
                    habits.append(Habit(
                        name=item['name'],
                        start_date=datetime.strptime(item['start_date'], '%Y-%m-%d').date(),
                        log=[datetime.strptime(log_date, '%Y-%m-%d').date() for log_date in item['log']],
                        periodicity=item.get('periodicity', 'daily')
                    ))
                return habits
        except FileNotFoundError:
            return []

    def save_db(self):
        """
        Saves the current habits to the JSON file.
        """
        data = []
        for habit in self.habits:
            data.append({
                'name': habit.name,
                'start_date': habit.start_date.strftime('%Y-%m-%d'),
                'log': [log_date.strftime('%Y-%m-%d') for log_date in habit.log],
                'periodicity': habit.periodicity
            })
        with open(self.db_file, "w") as file:
            json.dump(data, file, indent=4)

    def get_all_habits(self):
        """
        Retrieves all habits.

        Returns:
            list: A list of all Habit objects.
        """
        return self.habits

    def get_habit(self, name):
        """
        Retrieves a habit by name.

        Args:
            name (str): The name of the habit.

        Returns:
            Habit: The Habit object with the specified name.
        """
        for habit in self.habits:
            if habit.name == name:
                return habit
        return None

    def add_habit(self, habit):
        """
        Adds a new habit to the database.

        Args:
            habit (Habit): The Habit object to add.
        """
        self.habits.append(habit)
        self.save_db()

    def delete_habit(self, name):
        """
        Deletes a habit by name.

        Args:
            name (str): The name of the habit to delete.
        """
        self.habits = [habit for habit in self.habits if habit.name != name]
        self.save_db()

    def get_habits_by_periodicity(self, periodicity):
        """
        Retrieves all habits with the specified periodicity.

        Args:
            periodicity (str): The periodicity to filter habits by.

        Returns:
            list: A list of Habit objects with the specified periodicity.
        """
        return [habit for habit in self.habits if habit.periodicity == periodicity]

    def get_longest_streak_all_habits(self):
        """
        Retrieves the longest run streak of all defined habits.

        Returns:
            int: The longest streak of all habits.
        """
        return max((habit.calculate_streak() for habit in self.habits), default=0)

    def get_longest_streak_for_habit(self, name):
        """
        Retrieves the longest run streak for a given habit.

        Args:
            name (str): The name of the habit.

        Returns:
            int: The longest streak for the specified habit.
        """
        habit = self.get_habit(name)
        return habit.calculate_streak() if habit else 0
