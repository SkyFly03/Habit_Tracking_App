"""
This module provides the Habit class for managing individual habits.
"""

from datetime import datetime, timedelta

class Habit:
    """
    A class to represent a habit.
    """

    def __init__(self, name, start_date, log, periodicity='daily'):
        """
        Initializes a new Habit instance.

        Args:
            name (str): The name of the habit.
            start_date (datetime.date): The start date of the habit.
            log (list): A list of datetime.date objects representing the log of habit completions.
            periodicity (str): The periodicity of the habit ('daily' or 'weekly').
        """
        self.name = name
        self.start_date = start_date
        self.log = log
        self.periodicity = periodicity

    def calculate_streak(self):
        """
        Calculates the current streak of the habit.

        Returns:
            int: The current streak of consecutive completions.
        """
        streak = 0
        today = datetime.today().date()

        if not self.log:
            return streak

        sorted_log = sorted(self.log, reverse=True)
        current_date = sorted_log[0]

        if self.periodicity == 'daily':
            for log_date in sorted_log:
                if log_date == current_date:
                    streak += 1
                    current_date -= timedelta(days=1)
                else:
                    break
        elif self.periodicity == 'weekly':
            for log_date in sorted_log:
                if log_date >= current_date - timedelta(days=6):
                    streak += 1
                    current_date -= timedelta(days=7)
                else:
                    break

        return streak

    def log_entry(self, date):
        """
        Logs a new entry for the habit.

        Args:
            date (datetime.date): The date to log for the habit.
        """
        if date not in self.log:
            self.log.append(date)
            self.log = sorted(self.log)
