"""
This module provides functionality to analyze habits stored in the database.
"""

import questionary
from db import Database
from habit import Habit

def analyze_habits():
    """
    Analyzes the habits stored in the database and displays the current streak for a selected habit.

    Prompts the user to select a habit from the list of stored habits and displays the current streak
    of that habit based on its periodicity.
    """
    db = Database()
    habits = db.get_all_habits()

    if not habits:
        print("No habits found.")
        return

    habit_names = [habit.name for habit in habits]
    habit_name = questionary.select(
        "Select a habit to analyze:",
        choices=habit_names
    ).ask()

    if habit_name is None:
        return

    habit = db.get_habit(habit_name)
    print(f"Analyzing habit: {habit.name}")

    # Perform analysis
    streak = habit.calculate_streak()
    print(f"Current streak: {streak} {habit.periodicity} entries")

if __name__ == "__main__":
    analyze_habits()
